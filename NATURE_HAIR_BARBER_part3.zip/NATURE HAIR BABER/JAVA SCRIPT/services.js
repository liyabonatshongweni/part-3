/* ==========================================================
   services.js  -  Services page
   - Loads the service cards dynamically from services-data.js
   - Search box, category filter and sort dropdown
   - Accordion ("More details") on every card
   ========================================================== */
(function () {
  'use strict';

  var list = document.getElementById('services-list');
  var services = window.NHB_SERVICES;
  if (!list || !services) { return; } // static HTML stays as a fallback

  var searchInput = document.getElementById('service-search');
  var categorySelect = document.getElementById('service-category');
  var sortSelect = document.getElementById('service-sort');
  var countEl = document.getElementById('service-count');

  /* Small helper to build an element safely */
  function make(tag, className, text) {
    var el = document.createElement(tag);
    if (className) { el.className = className; }
    if (text !== undefined) { el.textContent = text; }
    return el;
  }

  /* ----- Build one service card ----- */
  function buildCard(service) {
    var card = make('div', 'service');

    card.appendChild(make('h2', '', service.name));
    card.appendChild(make('p', '', service.description));
    card.appendChild(make('p', 'price', 'R' + service.price));

    // Accordion button + panel
    var panelId = 'details-' + service.id;
    var toggle = make('button', 'details-toggle', 'More details');
    toggle.type = 'button';
    toggle.setAttribute('aria-expanded', 'false');
    toggle.setAttribute('aria-controls', panelId);

    var panel = make('div', 'details-panel');
    panel.id = panelId;
    panel.hidden = true;
    panel.appendChild(make('p', '', service.details));
    panel.appendChild(make('p', 'meta', 'Category: ' + service.category + '  |  Approx. time: ' + service.duration));

    var book = make('a', 'book-link', 'Enquire about this service');
    book.href = 'enquiry.html?service=' + encodeURIComponent(service.id);
    panel.appendChild(book);

    toggle.addEventListener('click', function () {
      var open = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', open ? 'false' : 'true');
      toggle.textContent = open ? 'More details' : 'Hide details';
      panel.hidden = open;
    });

    card.appendChild(toggle);
    card.appendChild(panel);
    return card;
  }

  /* ----- Work out what to show ----- */
  function getVisibleServices() {
    var term = searchInput ? searchInput.value.trim().toLowerCase() : '';
    var category = categorySelect ? categorySelect.value : 'all';
    var sort = sortSelect ? sortSelect.value : 'default';

    var result = services.filter(function (s) {
      var matchesText = !term ||
        s.name.toLowerCase().indexOf(term) !== -1 ||
        s.description.toLowerCase().indexOf(term) !== -1;
      var matchesCategory = category === 'all' || s.category === category;
      return matchesText && matchesCategory;
    });

    if (sort === 'price-low') { result.sort(function (a, b) { return a.price - b.price; }); }
    if (sort === 'price-high') { result.sort(function (a, b) { return b.price - a.price; }); }
    if (sort === 'name') { result.sort(function (a, b) { return a.name.localeCompare(b.name); }); }

    return result;
  }

  /* ----- Draw the list ----- */
  function render() {
    var visible = getVisibleServices();
    list.textContent = ''; // clear old cards (and the static fallback)

    if (visible.length === 0) {
      list.appendChild(make('p', 'no-results', 'No services match your search. Try a different word or clear the filter.'));
    } else {
      visible.forEach(function (s) {
        var card = buildCard(s);
        card.classList.add('reveal', 'is-visible'); // already on screen, no need to wait
        list.appendChild(card);
      });
    }

    if (countEl) {
      countEl.textContent = 'Showing ' + visible.length + ' of ' + services.length + ' services';
    }
  }

  /* ----- Fill the category dropdown from the data ----- */
  if (categorySelect) {
    var seen = {};
    services.forEach(function (s) {
      if (!seen[s.category]) {
        seen[s.category] = true;
        var opt = make('option', '', s.category);
        opt.value = s.category;
        categorySelect.appendChild(opt);
      }
    });
    categorySelect.addEventListener('change', render);
  }

  if (searchInput) { searchInput.addEventListener('input', render); }
  if (sortSelect) { sortSelect.addEventListener('change', render); }

  render();
})();
