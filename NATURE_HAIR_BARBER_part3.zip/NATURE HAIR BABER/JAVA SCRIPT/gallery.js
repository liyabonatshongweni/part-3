/* ==========================================================
   gallery.js  -  Gallery page
   Click any picture to open it larger in a lightbox.
   - Close with the X button, the Esc key, or by clicking the dark area
   - Move with the arrow buttons or the left/right arrow keys
   ========================================================== */
(function () {
  'use strict';

  var thumbs = Array.prototype.slice.call(document.querySelectorAll('.images img'));
  if (thumbs.length === 0) { return; }

  var current = 0;
  var lastFocused = null;

  /* ----- Build the lightbox once ----- */
  function make(tag, className, text) {
    var el = document.createElement(tag);
    if (className) { el.className = className; }
    if (text !== undefined) { el.textContent = text; }
    return el;
  }

  var overlay = make('div', 'lightbox');
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.setAttribute('aria-label', 'Image viewer');
  overlay.hidden = true;

  var closeBtn = make('button', 'lb-btn lb-close', '\u00D7');
  closeBtn.type = 'button';
  closeBtn.setAttribute('aria-label', 'Close image viewer');

  var prevBtn = make('button', 'lb-btn lb-prev', '\u2039');
  prevBtn.type = 'button';
  prevBtn.setAttribute('aria-label', 'Previous image');

  var nextBtn = make('button', 'lb-btn lb-next', '\u203A');
  nextBtn.type = 'button';
  nextBtn.setAttribute('aria-label', 'Next image');

  var figure = make('figure', 'lb-figure');
  var bigImg = make('img', 'lb-image');
  var caption = make('figcaption', 'lb-caption');
  figure.appendChild(bigImg);
  figure.appendChild(caption);

  overlay.appendChild(closeBtn);
  overlay.appendChild(prevBtn);
  overlay.appendChild(figure);
  overlay.appendChild(nextBtn);
  document.body.appendChild(overlay);

  /* ----- Show / open / close ----- */
  function show(index) {
    current = (index + thumbs.length) % thumbs.length; // wraps around
    var thumb = thumbs[current];
    bigImg.src = thumb.src;
    bigImg.alt = thumb.alt;
    caption.textContent = thumb.alt + '  (' + (current + 1) + ' / ' + thumbs.length + ')';
  }

  function open(index) {
    lastFocused = document.activeElement;
    show(index);
    overlay.hidden = false;
    document.body.classList.add('lb-open');
    closeBtn.focus();
  }

  function close() {
    overlay.hidden = true;
    document.body.classList.remove('lb-open');
    if (lastFocused) { lastFocused.focus(); }
  }

  /* ----- Make every thumbnail clickable and keyboard friendly ----- */
  thumbs.forEach(function (img, i) {
    img.tabIndex = 0;
    img.setAttribute('role', 'button');
    img.setAttribute('aria-label', 'Open larger image: ' + img.alt);
    img.classList.add('lb-thumb');
    img.addEventListener('click', function () { open(i); });
    img.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(i); }
    });
  });

  closeBtn.addEventListener('click', close);
  prevBtn.addEventListener('click', function () { show(current - 1); });
  nextBtn.addEventListener('click', function () { show(current + 1); });

  // Click on the dark background (but not the picture or buttons) closes it
  overlay.addEventListener('click', function (e) {
    if (e.target === overlay) { close(); }
  });

  document.addEventListener('keydown', function (e) {
    if (overlay.hidden) { return; }
    if (e.key === 'Escape') { close(); }
    if (e.key === 'ArrowLeft') { show(current - 1); }
    if (e.key === 'ArrowRight') { show(current + 1); }

    // Keep Tab inside the lightbox while it is open
    if (e.key === 'Tab') {
      var focusable = [closeBtn, prevBtn, nextBtn];
      var index = focusable.indexOf(document.activeElement);
      e.preventDefault();
      var next = e.shiftKey ? index - 1 : index + 1;
      focusable[(next + focusable.length) % focusable.length].focus();
    }
  });
})();
