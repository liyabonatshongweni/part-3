/* ==========================================================
   main.js  -  runs on every page
   1. Highlights the current page in the navigation
   2. Fade-in animation for elements as they scroll into view
   3. "Back to top" button (created with the DOM)
   4. Tabs (built from any element marked with data-tabs)
   ========================================================== */
(function () {
  'use strict';

  /* ---------- 1. Active navigation link ---------- */
  function highlightActiveLink() {
    var current = decodeURIComponent(location.pathname.split('/').pop() || '').toLowerCase();
    if (current === '') { current = 'home.html'; }

    document.querySelectorAll('nav a').forEach(function (link) {
      var target = decodeURIComponent((link.getAttribute('href') || '').split('/').pop()).toLowerCase();
      if (target === current) {
        link.classList.add('active');
        link.setAttribute('aria-current', 'page');
      }
    });
  }

  /* ---------- 2. Scroll reveal animation ---------- */
  function setupReveal() {
    var targets = document.querySelectorAll(
      '.content, .contact > *, .service, .images img, main > *, .form-card, .tabs'
    );
    if (!('IntersectionObserver' in window)) { return; } // no animation, content stays visible

    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });

    targets.forEach(function (el, i) {
      el.classList.add('reveal');
      el.style.transitionDelay = Math.min(i % 4, 3) * 80 + 'ms'; // small stagger
      observer.observe(el);
    });
  }

  /* ---------- 3. Back to top button ---------- */
  function setupBackToTop() {
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'back-to-top';
    btn.setAttribute('aria-label', 'Back to top');
    btn.textContent = '\u2191';
    document.body.appendChild(btn);

    window.addEventListener('scroll', function () {
      btn.classList.toggle('show', window.scrollY > 300);
    }, { passive: true });

    btn.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* ---------- 4. Tabs ----------
     HTML needed:
       <div data-tabs>
         <div data-tab-title="First">...</div>
         <div data-tab-title="Second">...</div>
       </div>
     The tab buttons are created here, so without JavaScript
     the visitor simply sees all the content one after the other. */
  function setupTabs() {
    document.querySelectorAll('[data-tabs]').forEach(function (group, g) {
      var panels = Array.prototype.slice.call(group.querySelectorAll(':scope > [data-tab-title]'));
      if (panels.length < 2) { return; }

      var list = document.createElement('div');
      list.className = 'tab-list';
      list.setAttribute('role', 'tablist');
      var buttons = [];

      panels.forEach(function (panel, i) {
        var id = 'tabgroup' + g + '-' + i;
        panel.id = id + '-panel';
        panel.className += ' tab-panel';
        panel.setAttribute('role', 'tabpanel');
        panel.setAttribute('aria-labelledby', id + '-tab');

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.id = id + '-tab';
        btn.className = 'tab-btn';
        btn.setAttribute('role', 'tab');
        btn.setAttribute('aria-controls', panel.id);
        btn.textContent = panel.getAttribute('data-tab-title');
        btn.addEventListener('click', function () { select(i, false); });
        btn.addEventListener('keydown', function (e) {
          var next = null;
          if (e.key === 'ArrowRight') { next = (i + 1) % panels.length; }
          if (e.key === 'ArrowLeft') { next = (i - 1 + panels.length) % panels.length; }
          if (next !== null) { e.preventDefault(); select(next, true); }
        });
        buttons.push(btn);
        list.appendChild(btn);
      });

      group.insertBefore(list, group.firstChild);

      function select(index, moveFocus) {
        panels.forEach(function (panel, i) {
          var active = i === index;
          panel.hidden = !active;
          buttons[i].setAttribute('aria-selected', active ? 'true' : 'false');
          buttons[i].tabIndex = active ? 0 : -1;
        });
        if (moveFocus) { buttons[index].focus(); }
      }
      select(0, false);
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    highlightActiveLink();
    setupTabs();      // before reveal so the tab block is included
    setupReveal();
    setupBackToTop();
  });
})();
