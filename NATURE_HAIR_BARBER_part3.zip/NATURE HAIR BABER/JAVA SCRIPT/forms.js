/* ==========================================================
   forms.js  -  Enquiry page and Contact page
   - JavaScript validation with error messages under each field
   - Enquiry form: shows a quote (cost) and availability
   - Contact form: sends the message with AJAX (fetch) so the page
     does not reload, then shows a success or error message
   ========================================================== */
(function () {
  'use strict';

  /* ---------------- Settings (edit these) ---------------- */
  var CONFIG = {
    // 1. Go to https://formspree.io, create a form that sends to your email,
    //    and replace YOUR_FORM_ID here AND in the action="" of Contact.html.
    //    Until you do, the form falls back to opening the visitor's email app.
    contactEndpoint: 'https://formspree.io/f/YOUR_FORM_ID',
    contactEmail: 'info@natureshairbaber.com',

    closedDays: [0],                      // 0 = Sunday, 1 = Monday ... 6 = Saturday
    timeSlots: ['09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00'],
    maxDaysAhead: 90
  };

  /* ---------------- Small helpers ---------------- */
  function make(tag, className, text) {
    var el = document.createElement(tag);
    if (className) { el.className = className; }
    if (text !== undefined) { el.textContent = text; }
    return el;
  }

  function toDateString(date) {
    var m = String(date.getMonth() + 1).padStart(2, '0');
    var d = String(date.getDate()).padStart(2, '0');
    return date.getFullYear() + '-' + m + '-' + d;
  }

  function findService(id) {
    var all = window.NHB_SERVICES || [];
    for (var i = 0; i < all.length; i++) {
      if (all[i].id === id) { return all[i]; }
    }
    return null;
  }

  /* ---------------- Validation rules ----------------
     Each rule gets the trimmed value and returns an error
     message, or an empty string when the value is fine. */
  var rules = {
    name: function (v) {
      if (!v) { return 'Please enter your full name.'; }
      if (!/^[A-Za-z\u00C0-\u024F' -]{2,50}$/.test(v)) {
        return 'Name must be 2 to 50 letters (spaces, hyphens and apostrophes are allowed).';
      }
      return '';
    },
    email: function (v) {
      if (!v) { return 'Please enter your email address.'; }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) { return 'Enter a valid email, for example name@example.com.'; }
      return '';
    },
    phone: function (v) {
      if (!v) { return 'Please enter your phone number.'; }
      var cleaned = v.replace(/[\s-]/g, '');
      if (!/^(\+27|0)[1-8]\d{8}$/.test(cleaned)) {
        return 'Enter a valid South African number, e.g. 063 875 6493 or +27 63 875 6493.';
      }
      return '';
    },
    service: function (v) { return v ? '' : 'Please choose a service.'; },
    people: function (v) {
      var n = Number(v);
      if (!v) { return 'Please enter how many people.'; }
      if (!Number.isInteger(n) || n < 1 || n > 5) { return 'Enter a whole number from 1 to 5.'; }
      return '';
    },
    date: function (v) {
      if (!v) { return 'Please choose a date.'; }
      var chosen = new Date(v + 'T00:00:00');
      var today = new Date();
      today.setHours(0, 0, 0, 0);
      var limit = new Date(today);
      limit.setDate(limit.getDate() + CONFIG.maxDaysAhead);

      if (isNaN(chosen.getTime())) { return 'Enter a valid date.'; }
      if (chosen < today) { return 'The date cannot be in the past.'; }
      if (chosen > limit) { return 'Please choose a date within the next ' + CONFIG.maxDaysAhead + ' days.'; }
      if (CONFIG.closedDays.indexOf(chosen.getDay()) !== -1) { return 'We are closed on that day. Please choose another date.'; }
      return '';
    },
    time: function (v) { return v ? '' : 'Please choose a time.'; },
    messageType: function (v) { return v ? '' : 'Please choose the type of message.'; },
    message: function (v) {
      if (!v) { return 'Please type your message.'; }
      if (v.length < 10) { return 'Your message is too short (at least 10 characters).'; }
      if (v.length > 500) { return 'Your message is too long (maximum 500 characters).'; }
      return '';
    },
    notes: function (v) { return v.length > 300 ? 'Notes can be 300 characters at most.' : ''; }
  };

  /* ---------------- Error display ---------------- */
  function errorElementFor(field) {
    var id = field.id + '-error';
    var el = document.getElementById(id);
    if (!el) {
      el = make('span', 'error-msg');
      el.id = id;
      field.insertAdjacentElement('afterend', el);
      field.setAttribute('aria-describedby', id);
    }
    return el;
  }

  function validateField(field) {
    var rule = rules[field.name];
    if (!rule) { return true; }

    var message = rule(field.value.trim());
    errorElementFor(field).textContent = message;
    field.setAttribute('aria-invalid', message ? 'true' : 'false');
    return message === '';
  }

  function clearErrors(form) {
    form.querySelectorAll('.error-msg').forEach(function (el) { el.textContent = ''; });
    form.querySelectorAll('[aria-invalid]').forEach(function (el) { el.removeAttribute('aria-invalid'); });
    form.querySelectorAll('[data-touched]').forEach(function (el) { el.removeAttribute('data-touched'); });
  }

  /* Attach validation to a form. onValid(form) runs only when every field passes. */
  function setupForm(form, onValid) {
    form.noValidate = true; // we show our own messages instead of the browser's

    var fields = Array.prototype.slice.call(form.elements).filter(function (el) {
      return el.name && rules[el.name];
    });

    fields.forEach(function (field) {
      field.addEventListener('blur', function () {
        field.setAttribute('data-touched', 'true');
        validateField(field);
      });
      field.addEventListener('input', function () {
        if (field.hasAttribute('data-touched')) { validateField(field); }
      });
      field.addEventListener('change', function () {
        field.setAttribute('data-touched', 'true');
        validateField(field);
      });
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var firstInvalid = null;

      fields.forEach(function (field) {
        field.setAttribute('data-touched', 'true');
        if (!validateField(field) && !firstInvalid) { firstInvalid = field; }
      });

      if (firstInvalid) { firstInvalid.focus(); return; }
      onValid(form);
    });
  }

  /* ==========================================================
     ENQUIRY FORM
     ========================================================== */
  function setupEnquiry(form) {
    var serviceSelect = form.elements.service;
    var timeSelect = form.elements.time;
    var dateInput = form.elements.date;
    var resultBox = document.getElementById('enquiry-result');

    // Fill the service dropdown from the shared data
    (window.NHB_SERVICES || []).forEach(function (s) {
      var opt = make('option', '', s.name + ' - R' + s.price);
      opt.value = s.id;
      serviceSelect.appendChild(opt);
    });

    // Fill the time dropdown
    CONFIG.timeSlots.forEach(function (t) {
      var opt = make('option', '', t);
      opt.value = t;
      timeSelect.appendChild(opt);
    });

    // Date limits: today up to maxDaysAhead
    var today = new Date();
    var limit = new Date();
    limit.setDate(limit.getDate() + CONFIG.maxDaysAhead);
    dateInput.min = toDateString(today);
    dateInput.max = toDateString(limit);

    // Pre-select a service if we arrived from the services page (enquiry.html?service=haircut)
    var preselect = new URLSearchParams(window.location.search).get('service');
    if (preselect && findService(preselect)) { serviceSelect.value = preselect; }

    /* Availability is simulated: a real shop would check a booking system.
       The same date and time always gives the same answer. */
    function isSlotFree(date, time) {
      var sum = 0;
      (date + time).split('').forEach(function (ch) { sum += ch.charCodeAt(0); });
      return sum % 5 !== 0;
    }

    function nextFreeSlot(date, afterTime) {
      for (var i = 0; i < CONFIG.timeSlots.length; i++) {
        var t = CONFIG.timeSlots[i];
        if (t > afterTime && isSlotFree(date, t)) { return t; }
      }
      return null;
    }

    function showQuote(f) {
      var service = findService(f.elements.service.value);
      var people = Number(f.elements.people.value);
      var date = f.elements.date.value;
      var time = f.elements.time.value;
      var total = service.price * people;
      var free = isSlotFree(date, time);

      resultBox.textContent = '';
      resultBox.className = 'quote-card ' + (free ? 'available' : 'unavailable');

      resultBox.appendChild(make('h2', '', 'Thank you, ' + f.elements.name.value.trim() + '!'));
      resultBox.appendChild(make('p', '', 'Here is your quote for ' + service.name + ':'));

      var table = make('ul', 'quote-list');
      table.appendChild(make('li', '', 'Price per person: R' + service.price));
      table.appendChild(make('li', '', 'Number of people: ' + people));
      table.appendChild(make('li', 'quote-total', 'Total cost: R' + total));
      table.appendChild(make('li', '', 'Approx. time: ' + service.duration));
      resultBox.appendChild(table);

      if (free) {
        resultBox.appendChild(make('p', 'quote-avail', 'Good news: ' + date + ' at ' + time + ' is available.'));
        resultBox.appendChild(make('p', '', 'We will confirm your booking at ' + f.elements.email.value.trim() + '.'));
      } else {
        var alt = nextFreeSlot(date, time);
        var msg = date + ' at ' + time + ' is fully booked.';
        msg += alt ? ' The next free time that day is ' + alt + '.' : ' Please try a different date.';
        resultBox.appendChild(make('p', 'quote-avail', msg));
      }

      resultBox.hidden = false;
      resultBox.setAttribute('tabindex', '-1');
      resultBox.focus();
      resultBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    setupForm(form, showQuote);

    form.addEventListener('reset', function () {
      clearErrors(form);
      resultBox.hidden = true;
    });
  }

  /* ==========================================================
     CONTACT FORM  (AJAX)
     ========================================================== */
  function setupContact(form) {
    var status = document.getElementById('contact-status');
    var button = form.querySelector('button[type="submit"]');

    function setStatus(text, type) {
      status.textContent = text;
      status.className = 'form-status ' + (type || '');
    }

    // Opens the visitor's email app. Used when no Formspree id has been added yet.
    function mailtoFallback(f) {
      var subject = 'Website message: ' + f.elements.messageType.value;
      var body = 'Name: ' + f.elements.name.value.trim() + '\n' +
                 'Email: ' + f.elements.email.value.trim() + '\n' +
                 'Phone: ' + f.elements.phone.value.trim() + '\n\n' +
                 f.elements.message.value.trim();
      window.location.href = 'mailto:' + CONFIG.contactEmail +
        '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);
      setStatus('Your email app should open with the message ready to send.', 'success');
    }

    async function send(f) {
      var endpoint = f.getAttribute('action') || CONFIG.contactEndpoint;

      if (endpoint.indexOf('YOUR_FORM_ID') !== -1) {
        mailtoFallback(f);
        return;
      }

      button.disabled = true;
      setStatus('Sending your message...', 'sending');

      var controller = new AbortController();
      var timer = setTimeout(function () { controller.abort(); }, 10000);

      try {
        var response = await fetch(endpoint, {
          method: 'POST',
          body: new FormData(f),
          headers: { 'Accept': 'application/json' },
          signal: controller.signal
        });

        if (response.ok) {
          f.reset();
          clearErrors(f);
          setStatus('Thank you! Your message has been sent. We will reply soon.', 'success');
        } else {
          setStatus('Sorry, something went wrong on our side. Please try again or phone us.', 'error');
        }
      } catch (err) {
        setStatus('We could not send your message. Please check your internet connection and try again.', 'error');
      } finally {
        clearTimeout(timer);
        button.disabled = false;
      }
    }

    setupForm(form, send);

    // Live character counter on the message box
    var box = form.elements.message;
    var counter = make('span', 'char-count', '0 / 500');
    box.insertAdjacentElement('afterend', counter);
    box.addEventListener('input', function () {
      counter.textContent = box.value.length + ' / 500';
    });
    form.addEventListener('reset', function () { counter.textContent = '0 / 500'; });
  }

  /* ---------------- Start ---------------- */
  document.addEventListener('DOMContentLoaded', function () {
    var enquiry = document.getElementById('enquiry-form');
    var contact = document.getElementById('contact-form');
    if (enquiry) { setupEnquiry(enquiry); }
    if (contact) { setupContact(contact); }
  });
})();
