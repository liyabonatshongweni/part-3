/* ==========================================================
   services-data.js
   One shared list of services. It is used by:
   - services.js  (builds the service cards, search, filter, sort)
   - forms.js     (fills the enquiry dropdown and works out the cost)
   Edit the details below to match your real business.
   ========================================================== */
window.NHB_SERVICES = [
  {
    id: 'haircut',
    name: 'Haircut',
    category: 'Hair',
    price: 150,
    duration: '45 min',
    description: 'Professional haircut and styling.',
    details: 'A full haircut with a quick consultation so you leave with the look you want.'
  },
  {
    id: 'hair-styling',
    name: 'Hair Styling',
    category: 'Hair',
    price: 100,
    duration: '30 min',
    description: 'Professional styling for your desired look.',
    details: 'Styling for events or everyday wear, finished with products that suit your hair.'
  },
  {
    id: 'beard-grooming',
    name: 'Beard Grooming',
    category: 'Beard',
    price: 100,
    duration: '30 min',
    description: 'Beard trimming and grooming.',
    details: 'Beard trim, shaping and clean-up of the neckline and cheek lines.'
  },
  {
    id: 'hair-treatment',
    name: 'Hair Treatment',
    category: 'Care',
    price: 120,
    duration: '40 min',
    description: 'Hair care and treatment services.',
    details: 'A nourishing treatment that helps keep hair and scalp healthy.'
  }
];
