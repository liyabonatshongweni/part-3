/* ==========================================================
   map.js  -  Contact page
   Interactive map using the Leaflet library and OpenStreetMap tiles.
   The Leaflet files are loaded from a CDN in Contact.html.
   ========================================================== */
(function () {
  'use strict';

  var mapEl = document.getElementById('map');
  if (!mapEl) { return; }

  // If Leaflet could not load (offline, blocked), show a simple message instead
  if (typeof L === 'undefined') {
    mapEl.textContent = 'The map could not be loaded. Our address is Braamfontein, South Africa.';
    return;
  }

  // Approximate position of Braamfontein, Johannesburg.
  // Change these two numbers to your exact shop location.
  var shop = [-26.1929, 28.0340];

  var map = L.map(mapEl, { scrollWheelZoom: false }).setView(shop, 15);

  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }).addTo(map);

  // Popup content built with DOM nodes
  var popup = document.createElement('div');
  var title = document.createElement('strong');
  title.textContent = "Nature's Hair Barber";
  popup.appendChild(title);
  popup.appendChild(document.createElement('br'));
  popup.appendChild(document.createTextNode('Braamfontein, South Africa'));
  popup.appendChild(document.createElement('br'));

  var directions = document.createElement('a');
  directions.href = 'https://www.openstreetmap.org/?mlat=' + shop[0] + '&mlon=' + shop[1] + '#map=16/' + shop[0] + '/' + shop[1];
  directions.target = '_blank';
  directions.rel = 'noopener';
  directions.textContent = 'Open larger map';
  popup.appendChild(directions);

  L.marker(shop).addTo(map).bindPopup(popup).openPopup();

  // Scroll-zoom only after the visitor clicks the map, so the page can still scroll
  map.on('focus', function () { map.scrollWheelZoom.enable(); });
  map.on('blur', function () { map.scrollWheelZoom.disable(); });
})();
